package com.example.proba2.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.proba2.data.WatchRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(navController: NavController, watchId: Int) {
    val watch = WatchRepository.getById(watchId)

    watch?.let {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text(it.name) })
            }
        ) { padding ->
            Column(modifier = Modifier.padding(padding).padding(16.dp)) {
                Text(text = it.description)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Cena: ${it.price} €", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(16.dp))

                Button(onClick = {
                    // Tu bo Unity AR del
                    // Pokličeš AR aktivnost ali povezavo
                }) {
                    Text("Poglej v AR")
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(onClick = {
                    // Tukaj dodamo v košarico (lahko kasneje)
                    navController.navigate("cart")
                }) {
                    Text("Dodaj v košarico")
                }
            }
        }
    } ?: Text("Ura ni najdena")
} 