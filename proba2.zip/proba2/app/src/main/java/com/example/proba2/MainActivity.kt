package com.example.proba2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.navigation.compose.rememberNavController
import com.example.proba2.ui.theme.Proba2Theme
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.proba2.ui.CartScreen
import com.example.proba2.ui.DetailScreen
import com.example.proba2.ui.HomeScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Proba2Theme {
                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "home") {
                    composable("home") { HomeScreen(navController) }
                    composable("details/{watchId}") { backStackEntry ->
                        val watchId = backStackEntry.arguments?.getString("watchId")?.toIntOrNull()
                        watchId?.let { DetailScreen(navController, it) }
                    }
                    composable("cart") { CartScreen(navController) }
                }
            }
        }
    }
}