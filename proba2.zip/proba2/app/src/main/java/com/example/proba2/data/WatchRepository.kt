package com.example.proba2.data

import com.example.proba2.model.Watch

object WatchRepository {
    val watches = listOf(
        Watch(1, "Rolex Submariner", 8999.99, "Ikonična športna ura.", ""),
        Watch(2, "Casio G-Shock", 149.99, "Vzdržljiva ura za vsak dan.", ""),
        Watch(3, "Omega Seamaster", 4999.99, "Elegantna in zmogljiva.", "")
    )

    fun getById(id: Int): Watch? = watches.find { it.id == id }
} 